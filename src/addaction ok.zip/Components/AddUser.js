import React, { Component } from 'react';

class AddUser extends Component {
    constructor(props) {
        super(props);
        this.state = {};
    }
    
    isChange = (event) => {
        const name = event.target.name ; 
        const value = event.target.value; 
        this.setState({
            [name] : value 
        });
       
      
        
    }
    submitForm = (event) => {
        //event.target.reset(); 
        var item = {}; 
        item.name = this.state.textName; 
        item.tel = this.state.textNumber;
        item.permission= this.state.textPermission;
        this.props.add(item);
    }
    kiemTraTrangThai = () =>{
        if(this.props.hienThiForm === true){
            return ( 
            <div className="col"> 
                <div className="card border-primary mb-3 mt-2">
                <div className="card-header">Thêm mới user vào hệ thống </div>
                <div className="card-body text-primary">
                  <div className="form-group">
                    <input type="text" name="textName" onChange={(event) => this.isChange(event) } className="form-control" placeholder="Tên User" />
                  </div>
                  <div className="form-group">
                    <input type="text" name="textNumber"  onChange={(event) => this.isChange(event) }  className="form-control" placeholder="Điện thoại " />
                  </div>
                  <div className="form-group">
                    <select name="textPermission"  className="custom-select" onChange={(event) => this.isChange(event) }  required>
                      <option value>Chọn Quyền mặc định </option>
                      <option value={1}>Admin</option>
                      <option value={2}>Modrator</option>
                      <option value={3}>Normal</option>
                    </select>
                  </div>
                  <div className="form-group">
                    <div className="btn btn-block btn-primary"  onClick={(event) => this.submitForm(event)}> Thêm mới </div>
                  </div>
                </div>
              </div>
              </div>
            )
        }
    }

    render() {
        console.log(this.state) ;
        return (
           
            <div >

            
                
              
               {
                   this.kiemTraTrangThai()
               }

             
             
          </div>
          
        );
    }
}

export default AddUser;